﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PizzaShop1_2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private PizzaShop1_2Entities context = new PizzaShop1_2Entities();
        public MainWindow()
        {
            InitializeComponent();
            EmployeesDgr.ItemsSource = context.Employees.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeesDgr.SelectedItem != null)
            {
                context.Employees.Remove(EmployeesDgr.SelectedItem as Employees);
                context.SaveChanges();
                EmployeesDgr.ItemsSource = context.Employees.ToList().ToList();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (EmployeesDgr.SelectedItem != null)
            {
                var selected = EmployeesDgr.SelectedItem as Employees;

                selected.first_name = NameTbx.Text;
                selected.last_name = LastNameTbx.Text;
                selected.position = PositionTbx.Text;
                selected.phone_number = PhoneTbx.Text;
                selected.email = EmailTbx.Text;
                selected.salary = SalaryTbx.Text;
                selected.work_schedule = WorkTbx.Text;
                context.SaveChanges();
                EmployeesDgr.ItemsSource = context.Employees.ToList().ToList();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Employees c = new Employees();
            c.first_name = NameTbx.Text;
            c.last_name = LastNameTbx.Text;
            c.position = PositionTbx.Text;
            c.phone_number = PhoneTbx.Text;
            c.email = EmailTbx.Text;
            c.salary = SalaryTbx.Text;
            c.work_schedule = WorkTbx.Text;
            context.Employees.Add(c);
            context.SaveChanges();
            EmployeesDgr.ItemsSource = context.Employees.ToList().ToList();
        }

        

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Window1 Window1 = new Window1();
            Window1.ShowDialog();
        }

        private void EmployeesDgr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (EmployeesDgr.SelectedItem != null)
            {
                var selected = EmployeesDgr.SelectedItem as Employees;
                NameTbx.Text = selected.first_name;
                LastNameTbx.Text = selected.last_name;
                PositionTbx.Text = selected.position;
                PhoneTbx.Text = selected.phone_number;
                EmailTbx.Text = selected.email;
                SalaryTbx.Text = selected.salary;
                WorkTbx.Text = selected.work_schedule;
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Window2 www = new Window2();
            www.Show();
            this.Close();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            Window1 www = new Window1();    
            www.Show();
            this.Close();
        }
    }
    
}
