﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PizzaShop1_2
{
    /// <summary>
    /// Логика взаимодействия для Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        private PizzaShop1_2Entities context = new PizzaShop1_2Entities();
        public Window4()
        {

            InitializeComponent();
            EmployeesDgr.ItemsSource = context.Suppliers.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeesDgr.SelectedItem != null)
            {
                context.Suppliers.Remove(EmployeesDgr.SelectedItem as Suppliers);
                context.SaveChanges();
                EmployeesDgr.ItemsSource = context.Suppliers.ToList().ToList();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (EmployeesDgr.SelectedItem != null)
            {
                var selected = EmployeesDgr.SelectedItem as Suppliers;

                selected.company_name = NameTbx.Text;
                selected.contact_first_name = LastNameTbx.Text;
                selected.contact_last_name = PositionTbx.Text;
                selected.phone_number = PhoneTbx.Text;
                selected.address = EmailTbx.Text;
                selected.email = SalaryTbx.Text;
                selected.supplied_goods_list = WorkTbx.Text;
                context.SaveChanges();
                EmployeesDgr.ItemsSource = context.Suppliers.ToList().ToList();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Suppliers c = new Suppliers();
            c.company_name = NameTbx.Text;
            c.contact_first_name = LastNameTbx.Text;
            c.contact_last_name = PositionTbx.Text;
            c.phone_number = PhoneTbx.Text;
            c.address = EmailTbx.Text;
            c.email = SalaryTbx.Text;
            c.supplied_goods_list = WorkTbx.Text;
            context.Suppliers.Add(c);
            context.SaveChanges();
            EmployeesDgr.ItemsSource = context.Suppliers.ToList().ToList();
        }
    }
}
