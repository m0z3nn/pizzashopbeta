﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PizzaShop1_2
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        private PizzaShop1_2Entities context = new PizzaShop1_2Entities();
        public Window3()
        {
            InitializeComponent();
            EmployeesDgr.ItemsSource = context.Ingredients.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (EmployeesDgr.SelectedItem != null)
            {
                var selected = EmployeesDgr.SelectedItem as Ingredients;

                selected.name = NameTbx.Text;
                selected.description = LastNameTbx.Text;
                selected.unit_of_measurement = PositionTbx.Text;
                selected.price_per_unit = PhoneTbx.Text;
                selected.quantity_in_stock = Convert.ToInt32(EmailTbx.Text);
                selected.country_of_origin = SalaryTbx.Text;
                context.SaveChanges();
                EmployeesDgr.ItemsSource = context.Ingredients.ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Ingredients c = new Ingredients();
            c.name = NameTbx.Text;
            c.description = LastNameTbx.Text;
            c.unit_of_measurement = PositionTbx.Text;
            c.price_per_unit = PhoneTbx.Text;
            c.quantity_in_stock = Convert.ToInt32(EmailTbx.Text);
            c.country_of_origin = SalaryTbx.Text;
            context.Ingredients.Add(c);
            context.SaveChanges();
            EmployeesDgr.ItemsSource = context.Ingredients.ToList();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (EmployeesDgr.SelectedItem != null)
            {
                context.Ingredients.Remove(EmployeesDgr.SelectedItem as Ingredients);
                context.SaveChanges();
                EmployeesDgr.ItemsSource = context.Ingredients.ToList();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Window1 ss = new Window1();   
            ss.Show();
            this.Close();
        }
    }
}
