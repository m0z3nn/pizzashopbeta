﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PizzaShop1_2
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            string roleName = GetRoleName(username, password);
            if (roleName != null)
            {
                // Пользователь аутентифицирован, открываем соответствующее окно на основе роли
                OpenWindowByRole(roleName);
            }
            else
            {
                MessageBox.Show("Не удалось аутентифицировать пользователя. Проверьте имя пользователя и пароль.", "Ошибка аутентификации", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GetRoleName(string Role_name, string password)
        {
            // Здесь вы можете выполнить запрос к базе данных или другую логику аутентификации
            // В этом примере проводится имитация проверки роли и пароля
            // Замените данный код на соответствующий код взаимодействия с вашей базой данных

            if (Role_name == "Админ" && password == "113114123")
            {
                return "Администратор";
            }
            else if (Role_name == "Сотрудник" && password == "123")
            {
                return "Сотрудник";
            }
            else
            {
                return null;
            }
        }

        private void OpenWindowByRole(string roleName)
        {
            // Открываем окно на основе роли
            switch (roleName)
            {
                case "Администратор":
                    Window1 adminWindow = new Window1();
                    adminWindow.Show();
                    Close();
                    break;
                case "Сотрудник":
                    Window1 employeeWindow = new Window1();
                    employeeWindow.Show();
                    Close();
                    break;
                case "Пользователь":
                    Window1 userWindow = new Window1();
                    userWindow.Show();
                    Close();
                    break;
                default:
                    MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    break;
            }
        }
    }
}

